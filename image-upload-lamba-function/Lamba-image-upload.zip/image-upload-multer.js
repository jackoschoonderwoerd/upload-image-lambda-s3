function readMtlAtClient(){

    mtlFileContent = '';

    var mtlFile = document.getElementById('mtlFileInput').files[0];
    var readerMTL = new FileReader();

    // Closure to capture the file information.
    readerMTL.onload = (function(reader) {
        return function() {
            mtlFileContent = reader.result;
            mtlFileContent = mtlFileContent.replace('data:;base64,', '');
            mtlFileContent = window.atob(mtlFileContent);
        };
    })(readerMTL);

    readerMTL.readAsDataURL(mtlFile);
}